/* TODO bot that demonstrates using slack on behalf of a user */
